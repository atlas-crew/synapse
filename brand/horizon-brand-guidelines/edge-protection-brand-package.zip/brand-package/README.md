# Edge Protection Brand Package

**Atlas Crew** · Horizon + Synapse · March 2026

---

## Quick Start

Open `reference/edge-protection-reference-card.html` in a browser for the complete visual cheatsheet. For AI agents, feed the markdown files from `reference/` as context.

## Contents

```
brand-package/
├── icons/                              Product icon marks
│   ├── horizon-icon.svg                Horizon — light background
│   ├── horizon-icon-dark.svg           Horizon — dark background
│   ├── horizon-icon.png                Horizon — raster
│   ├── synapse-icon.svg                Synapse — light background
│   ├── synapse-icon-dark.svg           Synapse — dark background
│   ├── synapse-icon.png                Synapse — raster
│   ├── beam-icon.svg                   Beam (observability module)
│   ├── beam-icon-dark.svg              Beam — dark
│   ├── bridge-icon.svg                 Bridge (deployment module)
│   └── bridge-icon-dark.svg            Bridge — dark
│
├── lockups/                            Logo + wordmark combinations
│   ├── combined-lockup-dark.svg        Horizon + Synapse side-by-side (colored wordmark)
│   ├── combined-lockup-dark.png        Horizon + Synapse raster
│   ├── combined-lockup-light-wordmark.svg  Same layout, white Recursive 300 wordmark
│   ├── horizon-lockup-dark.svg         Horizon standalone lockup
│   ├── horizon-lockup-dark.png         Horizon raster
│   ├── synapse-lockup-dark.svg         Synapse standalone lockup
│   ├── synapse-lockup-dark.png         Synapse raster
│   └── edge-protection-lockups.html    Interactive lockup reference (both products)
│
├── reference/                          Design system documentation
│   ├── QUICK-REFERENCE.md              ← Start here for AI agents
│   ├── COLOR-REFERENCE.md              Full color system with hex, CSS vars, Tailwind
│   ├── TYPOGRAPHY-REFERENCE.md         All 15 Recursive type roles with exact axis values
│   ├── USAGE-GUIDE.md                  Practical do/don't rules + component patterns
│   ├── edge-protection-reference-card.html   Visual cheatsheet (open in browser)
│   ├── edge-protection-reference-card.png    Cheatsheet as image
│   ├── edge-protection-reference-card.pdf    Cheatsheet as PDF
│   ├── color-reference.html            Interactive color swatches
│   ├── typography-reference.html       Live type specimens
│   └── usage-guide.html                Rendered component examples
│
└── README.md                           This file
```

## Brand Summary

### Products
- **Horizon** — Edge protection hub / fleet management platform
- **Synapse** — API/WAF protection sensor (Rust/Pingora, runs standalone)
- Modules: Bridge (deployment), Beam (observability)

### Font
**Recursive** variable font — one font, 15 roles. CASL axis encodes brand voice (warm for humans, clinical for data).

### Colors
- Primary: `#1E90FF` (blue)
- Accent: `#8B5CF6` (violet)
- Logo only: `#F97316` (coral) — never use as UI color
- Status: Red `#EF4444` · Amber `#F59E0B` · Green `#10B981` · Cyan `#06B6D4`

### Rules
1. Recursive font only — no Inter, Rubik, or system fonts
2. Border radius: 0 everywhere, no exceptions
3. Coral is for logos, not UI
4. CASL 0.6 for body text, CASL 0 for data
5. Display role uses wght 300 (lightest weight for biggest text)

### Wordmark Styles
- **Colored uppercase**: HORIZON in `#F97316`, SYNAPSE in `#A78BFA` (wide letter-spacing)
- **Light mixed case**: Horizon / Synapse in `#e8ecf4` (Recursive 300)

### Taglines
- Horizon: "See Further. Act Faster."
- Synapse: "On-Board Intelligence"
